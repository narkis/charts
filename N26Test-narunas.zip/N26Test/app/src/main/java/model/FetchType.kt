package com.narunas.n26test.model

enum class FetchType {
    MARKET_PRICE,
    TRANSACTION_AVERAGE
}